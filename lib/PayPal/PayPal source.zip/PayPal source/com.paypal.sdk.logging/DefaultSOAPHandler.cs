using com.paypal.sdk.exceptions;
using com.paypal.sdk.util;
using log4net;
using System;
using System.IO;
using System.Reflection;
using System.Text;
using System.Web.Services.Protocols;
using System.Xml;
using System.Xml.Xsl;

namespace com.paypal.sdk.logging
{
	public class DefaultSOAPHandler : SoapExtension
	{
		private static ILog log;

		private static XslTransform xslt;

		private Stream oldStream;

		private Stream newStream;

		static DefaultSOAPHandler()
		{
			DefaultSOAPHandler.log = LogManager.GetLogger("com.paypal.sdk.logging.DefaultSOAPHandler");
		}

		public DefaultSOAPHandler()
		{
		}

		public override Stream ChainStream(Stream stream)
		{
			this.oldStream = stream;
			this.newStream = new MemoryStream();
			return this.newStream;
		}

		private void Copy(Stream from, Stream to)
		{
			TextReader streamReader = new StreamReader(from);
			TextWriter streamWriter = new StreamWriter(to);
			streamWriter.WriteLine(streamReader.ReadToEnd());
			streamWriter.Flush();
		}

		public override object GetInitializer(LogicalMethodInfo methodInfo, SoapExtensionAttribute attribute)
		{
			return null;
		}

		public override object GetInitializer(Type type)
		{
			return null;
		}

		private void init()
		{
			if (DefaultSOAPHandler.xslt == null)
			{
				Stream manifestResourceStream = null;
				XmlTextReader xmlTextReader = null;
				try
				{
					try
					{
						Assembly executingAssembly = Assembly.GetExecutingAssembly();
						manifestResourceStream = executingAssembly.GetManifestResourceStream(string.Concat(Constants.RESOURCE_ROOT, ".resources.soapProtect.xsl"));
						xmlTextReader = new XmlTextReader(manifestResourceStream);
						DefaultSOAPHandler.xslt = new XslTransform();
						DefaultSOAPHandler.xslt.Load(xmlTextReader, null, null);
					}
					catch (Exception exception1)
					{
						Exception exception = exception1;
						throw new FatalException(MessageResources.GetMessage("XSLT_LOAD_ERROR"), exception);
					}
				}
				finally
				{
					try
					{
						if (xmlTextReader != null)
						{
							xmlTextReader.Close();
						}
					}
					catch (IOException oException)
					{
					}
					try
					{
						if (manifestResourceStream != null)
						{
							manifestResourceStream.Close();
						}
					}
					catch (IOException oException1)
					{
					}
				}
			}
		}

		public override void Initialize(object initializer)
		{
		}

		private void LogSoapEnvelope()
		{
			this.newStream.Position = 0;
			TextReader streamReader = new StreamReader(this.newStream, Encoding.UTF8);
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.Load(streamReader);
			Stream memoryStream = new MemoryStream();
			DefaultSOAPHandler.xslt.Transform(xmlDocument, null, memoryStream, null);
			memoryStream.Position = 0;
			DefaultSOAPHandler.log.Debug((new StreamReader(memoryStream)).ReadToEnd());
		}

		public override void ProcessMessage(SoapMessage message)
		{
			this.init();
			SoapMessageStage stage = message.Stage;
			switch (stage)
			{
				case SoapMessageStage.BeforeSerialize:
				case SoapMessageStage.AfterDeserialize:
				{
					try
					{
						this.WriteOutput(message);
						return;
					}
					catch (PayPalException payPalException1)
					{
						PayPalException payPalException = payPalException1;
						if (DefaultSOAPHandler.log.IsErrorEnabled)
						{
							DefaultSOAPHandler.log.Error(payPalException.Message, payPalException);
						}
						return;
					}
				}
				case SoapMessageStage.BeforeDeserialize:
				{
					try
					{
						this.WriteInput(message);
						return;
					}
					catch (PayPalException payPalException3)
					{
						PayPalException payPalException2 = payPalException3;
						if (DefaultSOAPHandler.log.IsErrorEnabled)
						{
							DefaultSOAPHandler.log.Error(payPalException2.Message, payPalException2);
						}
						return;
					}
				}
				default:
				{
					return;
				}
			}
		}

		private void WriteInput(SoapMessage message)
		{
			this.Copy(this.oldStream, this.newStream);
			if (DefaultSOAPHandler.log.IsDebugEnabled)
			{
				this.LogSoapEnvelope();
			}
			this.newStream.Position = 0;
		}

		private void WriteOutput(SoapMessage message)
		{
			if (DefaultSOAPHandler.log.IsDebugEnabled)
			{
				this.LogSoapEnvelope();
			}
			this.newStream.Position = 0;
			this.Copy(this.newStream, this.oldStream);
		}
	}
}