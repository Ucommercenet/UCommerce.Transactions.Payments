using log4net;

namespace com.paypal.sdk.logging
{
	public class DefaultLogger
	{
		public readonly static ILog LOG;

		static DefaultLogger()
		{
			DefaultLogger.LOG = LogManager.GetLogger("com.paypal.sdk.logging.DefaultLogger");
		}

		public DefaultLogger()
		{
		}
	}
}