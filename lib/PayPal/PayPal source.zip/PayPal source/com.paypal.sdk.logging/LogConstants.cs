namespace com.paypal.sdk.logging
{
	public enum LogConstants
	{
		LOG_NONE,
		LOG_TRANSACTION,
		LOG_DEBUG
	}
}