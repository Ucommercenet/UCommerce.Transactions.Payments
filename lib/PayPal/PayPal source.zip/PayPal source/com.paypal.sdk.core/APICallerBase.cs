using com.paypal.sdk.exceptions;
using com.paypal.sdk.profiles;
using com.paypal.sdk.util;
using System;
using System.Net;
using System.Security.Cryptography.X509Certificates;

namespace com.paypal.sdk.core
{
	public abstract class APICallerBase
	{
		private IAPIProfile profile;

		public IAPIProfile Profile
		{
			get
			{
				return this.profile;
			}
			set
			{
				this.validateProfile(value);
				this.SetupConnection(value);
				this.profile = value;
			}
		}

		protected APICallerBase()
		{
			this.profile = null;
			this.SetTrustManager();
		}

		public static X509Certificate GetCertificate(string name)
		{
			X509Certificate x509Certificate;
			X509Certificate x509Certificate1;
			IntPtr intPtr;
			IntPtr zero = IntPtr.Zero;
			uint num = 163840;
			IntPtr intPtr1 = Crypto32API.CertOpenStore((IntPtr)10, 0, IntPtr.Zero, num, "MY");
			if (intPtr1 != IntPtr.Zero)
			{
				do
				{
					IntPtr intPtr2 = Crypto32API.CertEnumCertificatesInStore(intPtr1, zero);
					zero = intPtr2;
					if (IntPtr.Zero == intPtr2)
					{
						Crypto32API.CertCloseStore(intPtr1, 0);
						num = 98304;
						intPtr1 = Crypto32API.CertOpenStore((IntPtr)10, 0, IntPtr.Zero, num, "MY");
						if (intPtr1 != IntPtr.Zero)
						{
							do
							{
								intPtr = Crypto32API.CertEnumCertificatesInStore(intPtr1, zero);
								zero = intPtr;
								if (IntPtr.Zero == intPtr)
								{
									Crypto32API.CertCloseStore(intPtr1, 0);
									throw new FatalException(string.Concat(MessageResources.GetMessage("CERTIFICATE_NOT_FOUND"), name));
								}
								x509Certificate1 = new X509Certificate(zero);
							}
							while (x509Certificate1.GetName().ToLower().IndexOf(name.Trim().ToLower()) < 0);
							Crypto32API.CertCloseStore(intPtr1, 0);
							return x509Certificate1;
						}
						Crypto32API.CertCloseStore(intPtr1, 0);
						throw new FatalException(string.Concat(MessageResources.GetMessage("CERTIFICATE_NOT_FOUND"), name));
					}
					x509Certificate = new X509Certificate(zero);
				}
				while (x509Certificate.GetName().ToLower().IndexOf(name.Trim().ToLower()) < 0);
				Crypto32API.CertCloseStore(intPtr1, 0);
				return x509Certificate;
			}
			Crypto32API.CertCloseStore(intPtr1, 0);
			num = 98304;
			intPtr1 = Crypto32API.CertOpenStore((IntPtr)10, 0, IntPtr.Zero, num, "MY");
			if (intPtr1 != IntPtr.Zero)
			{
				do
				{
					intPtr = Crypto32API.CertEnumCertificatesInStore(intPtr1, zero);
					zero = intPtr;
					if (IntPtr.Zero == intPtr)
					{
						Crypto32API.CertCloseStore(intPtr1, 0);
						throw new FatalException(string.Concat(MessageResources.GetMessage("CERTIFICATE_NOT_FOUND"), name));
					}
					x509Certificate1 = new X509Certificate(zero);
				}
				while (x509Certificate1.GetName().ToLower().IndexOf(name.Trim().ToLower()) < 0);
				Crypto32API.CertCloseStore(intPtr1, 0);
				return x509Certificate1;
			}
			Crypto32API.CertCloseStore(intPtr1, 0);
			throw new FatalException(string.Concat(MessageResources.GetMessage("CERTIFICATE_NOT_FOUND"), name));
		}

		private void SetTrustManager()
		{
			if (Config.Instance.TrustAll)
			{
				ServicePointManager.CertificatePolicy = new MyPolicy();
			}
		}

		protected abstract void SetupConnection(IAPIProfile cprofile);

		protected virtual void validateProfile(IAPIProfile _profile)
		{
			if (_profile != null)
			{
				return;
			}
			else
			{
				throw new WarningException(MessageResources.GetMessage("PROFILE_INVALID"));
			}
		}
	}
}