using System;

namespace com.paypal.sdk.core
{
	public class ConfigDefaults
	{
		public const bool TRUST_ALL = true;

		public const int MAXIMUM_RETRIES = 0;

		public const string WSDL_VERSION = "64.0";

		public const int DELAY_TIME = 2000;

		public const int CONNECTION_TIMEOUT_MS = 360000;

		public ConfigDefaults()
		{
		}
	}
}