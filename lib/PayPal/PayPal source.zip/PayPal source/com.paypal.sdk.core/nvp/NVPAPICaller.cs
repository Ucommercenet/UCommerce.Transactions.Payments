using com.paypal.sdk.core;
using com.paypal.sdk.exceptions;
using com.paypal.sdk.profiles;
using com.paypal.sdk.rules;
using com.paypal.sdk.util;
using log4net;
using System;
using System.Collections;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace com.paypal.sdk.core.nvp
{
	public class NVPAPICaller : APICallerBase
	{
		private const string CVV2 = "CVV2";

		private const string SIGNATURE = "SIGNATURE";

		private const string PWD = "PWD";

		private const string ACCT = "ACCT";

		private readonly static ILog log;

		private string pendpointurl;

		private X509Certificate x509;

		private readonly static string[] SECURED_NVPS;

		static NVPAPICaller()
		{
			NVPAPICaller.log = LogManager.GetLogger(typeof(NVPAPICaller));
			string[] strArray = new string[4];
			strArray[0] = "ACCT";
			strArray[1] = "CVV2";
			strArray[2] = "SIGNATURE";
			strArray[3] = "PWD";
			NVPAPICaller.SECURED_NVPS = strArray;
		}

		public NVPAPICaller()
		{
			this.pendpointurl = string.Empty;
		}

		private static string buildCredentialsNVPString(IAPIProfile profile, string nvprequest)
		{
			NVPCodec nVPCodec = new NVPCodec();
			if (profile as SignatureAPIProfile == null || Utils.IsEmpty(profile.APISignature))
			{
				if (profile as UniPayAPIProfile == null)
				{
					if (!Utils.IsEmpty(profile.APIUsername))
					{
						nVPCodec["USER"] = profile.APIUsername;
					}
					if (!Utils.IsEmpty(profile.APIPassword))
					{
						nVPCodec["PWD"] = profile.APIPassword;
					}
					if (!Utils.IsEmpty(profile.Subject))
					{
						nVPCodec["SUBJECT"] = profile.Subject;
					}
				}
				else
				{
					if (!Utils.IsEmpty(profile.getFirstPartyEmail))
					{
						nVPCodec["SUBJECT"] = profile.getFirstPartyEmail;
					}
				}
			}
			else
			{
				if (!Utils.IsEmpty(profile.APIUsername))
				{
					nVPCodec["USER"] = profile.APIUsername;
				}
				if (!Utils.IsEmpty(profile.APIPassword))
				{
					nVPCodec["PWD"] = profile.APIPassword;
				}
				if (profile is SignatureAPIProfile && !Utils.IsEmpty(profile.APISignature))
				{
					nVPCodec["SIGNATURE"] = profile.APISignature;
				}
				if (!Utils.IsEmpty(profile.Subject))
				{
					nVPCodec["SUBJECT"] = profile.Subject;
				}
			}
			if (nvprequest.ToUpper().IndexOf("VERSION=") == -1)
			{
				nVPCodec["VERSION"] = MessageResources.GetMessage("WSDLVERSION");
			}
			nVPCodec["SOURCE"] = MessageResources.GetMessage("SOURCE");
			return nVPCodec.Encode();
		}

		public string Call(string NvpRequest)
		{
			string str;
			X509Certificate x509Certificate;
			this.validateProfile(base.Profile);
			string str1 = this.pendpointurl;
			string str2 = string.Concat(NvpRequest, "&", NVPAPICaller.buildCredentialsNVPString(base.Profile, NvpRequest));
			DateTime now = DateTime.Now;
			if (NVPAPICaller.log.IsInfoEnabled)
			{
				NVPCodec nVPCodec = new NVPCodec();
				nVPCodec.Decode(str2);
				string[] sECUREDNVPS = NVPAPICaller.SECURED_NVPS;
				for (int i = 0; i < (int)sECUREDNVPS.Length; i++)
				{
					string str3 = sECUREDNVPS[i];
					if (nVPCodec.Get(str3) != null)
					{
						StringBuilder stringBuilder = new StringBuilder();
						stringBuilder.Append('*', nVPCodec[str3].Length);
						nVPCodec[str3] = stringBuilder.ToString();
					}
				}
				NVPAPICaller.log.Info(string.Concat(nVPCodec.Encode(), MessageResources.GetMessage("TRANSACTION_SENT")));
			}
			try
			{
				string str4 = str1;
				string str5 = str2;
				int timeout = base.Profile.Timeout;
				if (base.Profile is CertificateAPIProfile)
				{
					x509Certificate = this.x509;
				}
				else
				{
					x509Certificate = null;
				}
				str = Utils.HttpPost(str4, str5, timeout, x509Certificate);
			}
			catch (Exception exception1)
			{
				Exception exception = exception1;
				throw new FatalException(exception.Message);
			}
			if (NVPAPICaller.log.IsInfoEnabled)
			{
				object[] message = new object[7];
				message[0] = MessageResources.GetMessage("TRANSACTION_RESULT");
				message[1] = MessageResources.GetMessage("ELAPSED_TIME");
				TimeSpan timeSpan = DateTime.Now - now;
				message[2] = timeSpan.Seconds;
				message[3] = "s ";
				timeSpan = DateTime.Now - now;
				message[4] = timeSpan.Milliseconds;
				message[5] = " ms ";
				message[6] = str;
				NVPAPICaller.log.Info(string.Concat(message));
			}
			return str;
		}

		protected override void SetupConnection(IAPIProfile cprofile)
		{
			string environment = cprofile.Environment;
			bool flag = Utils.IsStage(environment);
			if (!flag)
			{
				Endpoint endpoint = Config.Instance.GetEndpoint(environment, MessageResources.GetMessage("NVPPORT"), cprofile is SignatureAPIProfile);
				if (endpoint == null || endpoint.Url == null)
				{
					throw new TransactionException(MessageResources.GetMessage("ENDPOINT_NOT_FOUND"));
				}
				else
				{
					this.pendpointurl = endpoint.Url;
				}
			}
			else
			{
				this.pendpointurl = string.Concat("https://api.", environment, ".paypal.com/nvp");
			}
			if (cprofile is CertificateAPIProfile)
			{
				this.x509 = APICallerBase.GetCertificate(cprofile.APIUsername);
			}
		}

		protected override void validateProfile(IAPIProfile profile)
		{
			if (profile is SignatureAPIProfile || profile is CertificateAPIProfile)
			{
				ValidationErrors validationError = new ValidationErrors();
				if (profile is CertificateAPIProfile)
				{
					if (Utils.IsEmpty(profile.CertificateFile))
					{
						validationError.Add(new ValidationError(MessageResources.GetMessage("API_CERTIFICATE_FILE_EMPTY")));
					}
					if (Utils.IsEmpty(profile.PrivateKeyPassword))
					{
						validationError.Add(new ValidationError(MessageResources.GetMessage("API_PRIVATE_KEY_PASSWORD_EMPTY")));
					}
				}
				if (!validationError.IsEmpty())
				{
					StringBuilder stringBuilder = new StringBuilder(MessageResources.GetMessage("PROFILE_INVALID"));
					IEnumerator enumerator = validationError.GetEnumerator();
					while (enumerator.MoveNext())
					{
						ValidationError current = (ValidationError)enumerator.Current;
						stringBuilder.Append(string.Concat("\n", current.Key));
					}
					throw new TransactionException(stringBuilder.ToString());
				}
			}
		}
	}
}