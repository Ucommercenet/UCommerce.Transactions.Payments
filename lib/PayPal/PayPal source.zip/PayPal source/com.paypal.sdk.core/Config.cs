using com.paypal.sdk.resources;
using com.paypal.sdk.util;
using log4net;
using log4net.Config;
using System;
using System.Collections;
using System.Configuration;
using System.IO;
using System.Reflection;
using System.Xml;

namespace com.paypal.sdk.core
{
	public class Config
	{
		public const string PAYPAL_TAG = "paypal";

		private static string applicationBase;

		private static ILog log;

		private readonly static object syncRoot;

		private static Config instance;

		private readonly Hashtable endpoints;

		public readonly bool TrustAll;

		public readonly int MaximumRetries;

		private static XmlNode AppDomainConfigSection
		{
			get
			{
				return (XmlNode)ConfigurationSettings.GetConfig("paypal");
			}
		}

		public static string ApplicationBase
		{
			get
			{
				return Config.applicationBase;
			}
			set
			{
				string[] message;
				if (!Config.IsApplicationBaseSet)
				{
					if (value != null)
					{
						string fullPath = Path.GetFullPath(value.Trim());
						if (Directory.Exists(fullPath))
						{
							Config.applicationBase = fullPath;
							message = new string[6];
							message[0] = MessageResources.GetMessage("APPBASE_SET");
							message[1] = " value : '";
							message[2] = value;
							message[3] = "', full path '";
							message[4] = fullPath;
							message[5] = "'";
							Config.log.Debug(string.Concat(message));
							return;
						}
						else
						{
							message = new string[6];
							message[0] = MessageResources.GetMessage("SET_APPBASE_MULTIPLE");
							message[1] = " value : '";
							message[2] = value;
							message[3] = "', full path : '";
							message[4] = fullPath;
							message[5] = "'.";
							throw new FileNotFoundException(string.Concat(message));
						}
					}
					else
					{
						throw new ArgumentNullException("applicationBase");
					}
				}
				else
				{
					Config.log.Warn(string.Concat(MessageResources.GetMessage("SET_APPBASE_MULTIPLE"), value));
					return;
				}
			}
		}

		private static Stream DefaultEndpointsStream
		{
			get
			{
				string str = ".resources.paypal-endpoints-nvp.xml";
				return ResourceHelper.GetResourceStream(str);
			}
		}

		public static Config Instance
		{
			get
			{
				lock (Config.syncRoot)
				{
					if (Config.instance == null)
					{
						Config.instance = new Config();
					}
				}
				return Config.instance;
			}
		}

		private static bool IsApplicationBaseSet
		{
			get
			{
				return Config.ApplicationBase != string.Empty;
			}
		}

		static Config()
		{
			Config.applicationBase = string.Empty;
			Config.log = Config.GetLogger();
			Config.syncRoot = new object();
			Config.instance = null;
			try
			{
				XmlConfigurator.Configure(LogManager.GetRepository());
			}
			catch
			{
			}
		}

		private Config()
		{
			XmlNode appDomainConfigSection;
			this.TrustAll = true;
			this.MaximumRetries = 0;
			if (!Config.IsApplicationBaseSet)
			{
				appDomainConfigSection = Config.AppDomainConfigSection;
			}
			else
			{
				ManualConfig manualConfig = new ManualConfig(Config.ApplicationBase);
				manualConfig.Run();
				appDomainConfigSection = manualConfig.ExternalFileConfigSection;
			}
			this.TrustAll = true;
			this.MaximumRetries = 0;
			XmlNode xmlNode = Utils.CreateXmlNode(Config.DefaultEndpointsStream);
			this.endpoints = ConfigSectionParser.ReadEndpoints(xmlNode);
			if (appDomainConfigSection != null)
			{
				Config.log.Debug(MessageResources.GetMessage("READING_OVERRIDES"));
				ConfigSectionParser configSectionParser = new ConfigSectionParser(appDomainConfigSection);
				if (configSectionParser.IsTrustAllSpecified)
				{
					this.TrustAll = configSectionParser.TrustAll;
				}
				if (configSectionParser.IsMaximumRetriesSpecified)
				{
					this.MaximumRetries = configSectionParser.MaximumRetries;
				}
				if (configSectionParser.IsEndpointsSpecified)
				{
					this.endpoints = configSectionParser.Endpoints;
				}
			}
			Config.log.Debug(string.Concat(MessageResources.GetMessage("CURRENT_ASSEMBLY_VERSION"), Assembly.GetExecutingAssembly().FullName));
			Config.log.Debug(string.Concat(MessageResources.GetMessage("TRUST_ALL"), this.TrustAll));
			Config.log.Debug(string.Concat(MessageResources.GetMessage("ENDPOINTS_LOADED"), this.endpoints.Count));
			if (this.endpoints.Count == 0)
			{
				Config.log.Warn(MessageResources.GetMessage("ENDPOINTS_EMPTY"));
			}
		}

		public Endpoint GetEndpoint(string environment, string port, bool isThreeToken)
		{
			return (Endpoint)this.endpoints[ConfigSectionParser.GetEndpointKey(environment, port, isThreeToken)];
		}

		private static ILog GetLogger()
		{
			return LogManager.GetLogger("com.paypal.sdk.core.Config");
		}
	}
}