using System;

namespace com.paypal.sdk.core
{
	public class Endpoint
	{
		private readonly string environment;

		private readonly string port;

		private readonly bool isThreeToken;

		private readonly string url;

		public string Environment
		{
			get
			{
				return this.environment;
			}
		}

		public bool IsThreeToken
		{
			get
			{
				return this.isThreeToken;
			}
		}

		public string Port
		{
			get
			{
				return this.port;
			}
		}

		public string Url
		{
			get
			{
				return this.url;
			}
		}

		public string WebHost
		{
			get
			{
				return string.Concat("www", (new Uri(this.url)).Host.Substring("api".Length));
			}
		}

		public Endpoint(string environment, string port, bool isThreeToken, string url)
		{
			this.environment = environment;
			this.port = port;
			this.isThreeToken = isThreeToken;
			this.url = url;
		}
	}
}