using com.paypal.sdk.util;
using log4net;
using System;
using System.Collections;
using System.Globalization;
using System.Xml;

namespace com.paypal.sdk.core
{
	internal class ConfigSectionParser
	{
		public readonly static ILog log;

		private readonly XmlNode configSection;

		public readonly bool IsTrustAllSpecified;

		public readonly bool TrustAll;

		public readonly bool IsMaximumRetriesSpecified;

		public readonly int MaximumRetries;

		public readonly bool IsEndpointsSpecified;

		public readonly Hashtable Endpoints;

		static ConfigSectionParser()
		{
			ConfigSectionParser.log = LogManager.GetLogger("com.paypal.sdk.core.ConfigSectionParser");
		}

		public ConfigSectionParser(XmlNode configSection)
		{
			this.IsTrustAllSpecified = false;
			this.TrustAll = false;
			this.IsMaximumRetriesSpecified = false;
			this.MaximumRetries = 0;
			this.IsEndpointsSpecified = false;
			this.Endpoints = new Hashtable();
			if (configSection != null)
			{
				this.configSection = configSection;
				string settingValue = ConfigSectionParser.GetSettingValue("trustAll", configSection);
				if (settingValue != null)
				{
					try
					{
						this.TrustAll = bool.Parse(settingValue);
						this.IsTrustAllSpecified = true;
					}
					catch
					{
					}
				}
				string str = ConfigSectionParser.GetSettingValue("maximumRetries", configSection);
				if (str != null)
				{
					try
					{
						this.MaximumRetries = int.Parse(str);
						this.IsMaximumRetriesSpecified = true;
					}
					catch
					{
					}
				}
				XmlNode endpointsNodeFromConfig = this.GetEndpointsNodeFromConfig();
				if (endpointsNodeFromConfig != null)
				{
					try
					{
						this.Endpoints = ConfigSectionParser.ReadEndpoints(endpointsNodeFromConfig);
						this.IsEndpointsSpecified = true;
					}
					catch
					{
					}
				}
				return;
			}
			else
			{
				throw new ArgumentNullException("configSection");
			}
		}

		public static string GetEndpointKey(string environment, string port, bool isThreeToken)
		{
			string empty;
			string lower = environment.ToLower();
			string str = "-";
			string lower1 = port.ToLower();
			if (isThreeToken)
			{
				empty = "-threeToken";
			}
			else
			{
				empty = string.Empty;
			}
			return string.Concat(lower, str, lower1, empty);
		}

		private XmlNode GetEndpointsNodeFromConfig()
		{
			XmlNode xmlNode = null;
			if (this.configSection == null)
			{
				ConfigSectionParser.log.Debug("config section is null");
			}
			else
			{
				xmlNode = this.configSection.SelectSingleNode("endpoints");
			}
			return xmlNode;
		}

		private static string GetSettingValue(string tagName, XmlNode configSection)
		{
			string value = null;
			if (configSection != null)
			{
				XmlNode xmlNode = configSection.SelectSingleNode(string.Concat(tagName, "/@value"));
				if (xmlNode != null)
				{
					value = xmlNode.Value;
				}
			}
			return value;
		}

		private static bool IsThreeToken(XmlNode environmentNode)
		{
			bool flag = false;
			try
			{
				flag = bool.Parse(environmentNode.SelectSingleNode("@threetoken").Value);
			}
			catch
			{
			}
			return flag;
		}

		private static void LogIfNull(XmlNode minVersionNode, string message)
		{
			if (minVersionNode == null && ConfigSectionParser.log.IsDebugEnabled)
			{
				ConfigSectionParser.log.Debug(message);
			}
		}

		private static bool NonNull(params object[] args)
		{
			object[] objArray = args;
			int num = 0;
			while (num < (int)objArray.Length)
			{
				object obj = objArray[num];
				if (obj != null)
				{
					num++;
				}
				else
				{
					bool flag = false;
					return flag;
				}
			}
			return true;
		}

		private static double ParseDouble(string minVersionStr)
		{
			return double.Parse(minVersionStr, NumberFormatInfo.InvariantInfo);
		}

		public static Hashtable ReadEndpoints(XmlNode root)
		{
			if (root != null)
			{
				Hashtable hashtable = new Hashtable();
				XmlNodeList xmlNodeList = root.SelectNodes("wsdl/environment");
				foreach (XmlNode xmlNode in xmlNodeList)
				{
					string value = xmlNode.SelectSingleNode("@name").Value;
					foreach (XmlNode xmlNode1 in xmlNode.SelectNodes("port"))
					{
						bool flag = ConfigSectionParser.IsThreeToken(xmlNode1);
						XmlNode xmlNode2 = xmlNode1.SelectSingleNode("@name");
						ConfigSectionParser.LogIfNull(xmlNode2, "port name attribute not found in endpoints");
						object[] objArray = new object[1];
						objArray[0] = xmlNode2;
						if (!ConfigSectionParser.NonNull(objArray))
						{
							continue;
						}
						string str = xmlNode2.Value;
						string innerText = xmlNode1.InnerText;
						string endpointKey = ConfigSectionParser.GetEndpointKey(value, str, flag);
						Endpoint endpoint = new Endpoint(value, str, flag, innerText);
						hashtable.Add(endpointKey, endpoint);
						if (!ConfigSectionParser.log.IsDebugEnabled)
						{
							continue;
						}
						string[] message = new string[8];
						message[0] = MessageResources.GetMessage("ENDPOINT_FOUND");
						message[1] = "'";
						message[2] = endpointKey;
						message[3] = "', environment: '";
						message[4] = value;
						message[5] = "', port: '";
						message[6] = str;
						message[7] = "'";
						ConfigSectionParser.log.Debug(string.Concat(message));
					}
				}
				return hashtable;
			}
			else
			{
				throw new ArgumentNullException("node");
			}
		}
	}
}