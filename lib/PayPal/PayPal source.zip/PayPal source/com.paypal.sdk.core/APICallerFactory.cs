using com.paypal.sdk.core.nvp;

namespace com.paypal.sdk.core
{
	public class APICallerFactory
	{
		public APICallerFactory()
		{
		}

		public static APICallerBase createNVPAPICaller()
		{
			return new NVPAPICaller();
		}
	}
}