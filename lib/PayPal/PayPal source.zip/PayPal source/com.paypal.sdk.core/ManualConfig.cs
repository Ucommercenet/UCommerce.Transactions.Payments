using com.paypal.sdk.util;
using log4net.Config;
using System;
using System.IO;
using System.Xml;

namespace com.paypal.sdk.core
{
	internal class ManualConfig
	{
		private const string CONFIG_FILE = "Web.config";

		private const string LOG4NET_TAG = "log4net";

		private readonly string applicationBase;

		public XmlNode ExternalFileConfigSection
		{
			get
			{
				XmlNode xmlNode;
				StreamReader externalConfigFileStream = this.GetExternalConfigFileStream();
				try
				{
					XmlNode xmlNode1 = Utils.CreateXmlNode(externalConfigFileStream);
					XmlNode xmlNode2 = xmlNode1.SelectSingleNode("paypal");
					xmlNode = xmlNode2;
				}
				finally
				{
					if (externalConfigFileStream != null)
					{
						externalConfigFileStream.Dispose();
					}
				}
				return xmlNode;
			}
		}

		public ManualConfig(string applicationBase)
		{
			this.applicationBase = applicationBase;
		}

		private void ConfigureLog4Net()
		{
			StreamReader externalConfigFileStream = this.GetExternalConfigFileStream();
			try
			{
				XmlElement xmlElement = (XmlElement)Utils.CreateXmlNode(externalConfigFileStream).SelectSingleNode("log4net");
				if (xmlElement != null)
				{
					this.QualifyRelativePaths(xmlElement);
					XmlConfigurator.Configure(xmlElement);
				}
			}
			finally
			{
				if (externalConfigFileStream != null)
				{
					externalConfigFileStream.Dispose();
				}
			}
		}

		private StreamReader GetExternalConfigFileStream()
		{
			string str = Path.Combine(this.applicationBase, "Web.config");
			return new StreamReader(str);
		}

		private void QualifyRelativePaths(XmlElement log4netnode)
		{
			XmlNodeList xmlNodeList = log4netnode.SelectNodes("appender/file/@value");
			foreach (XmlNode xmlNode in xmlNodeList)
			{
				if (Path.IsPathRooted(xmlNode.Value))
				{
					continue;
				}
				string str = Path.Combine(this.applicationBase, xmlNode.Value).Replace(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
				xmlNode.Value = str;
			}
		}

		public void Run()
		{
			this.ConfigureLog4Net();
		}
	}
}