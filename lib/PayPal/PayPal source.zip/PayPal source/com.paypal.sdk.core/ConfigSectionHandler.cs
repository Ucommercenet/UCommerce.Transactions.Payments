using System;
using System.Configuration;
using System.Xml;

namespace com.paypal.sdk.core
{
	public class ConfigSectionHandler : IConfigurationSectionHandler
	{
		public ConfigSectionHandler()
		{
		}

		public object Create(object parent, object configContext, XmlNode section)
		{
			return section;
		}
	}
}