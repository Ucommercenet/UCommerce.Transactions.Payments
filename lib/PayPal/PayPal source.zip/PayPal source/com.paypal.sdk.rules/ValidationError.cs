using System;

namespace com.paypal.sdk.rules
{
	[Serializable]
	public class ValidationError
	{
		private string key;

		public string Key
		{
			get
			{
				return this.key;
			}
			set
			{
				this.key = value;
			}
		}

		public ValidationError(string key)
		{
			this.key = key;
		}
	}
}