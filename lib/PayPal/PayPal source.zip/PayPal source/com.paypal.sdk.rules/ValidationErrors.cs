using System;
using System.Collections;

namespace com.paypal.sdk.rules
{
	[Serializable]
	public class ValidationErrors
	{
		private bool accessed;

		private ArrayList errors;

		public ValidationErrors()
		{
			this.accessed = false;
			this.errors = new ArrayList();
		}

		public void Add(ValidationError error)
		{
			this.errors.Add(error);
		}

		public void Clear()
		{
			this.errors.Clear();
		}

		public IEnumerator GetEnumerator()
		{
			this.accessed = true;
			return this.errors.GetEnumerator();
		}

		public bool IsAccessed()
		{
			return this.accessed;
		}

		public bool IsEmpty()
		{
			if (this.errors.Count != 0)
			{
				return false;
			}
			else
			{
				return true;
			}
		}

		public int Size()
		{
			return this.errors.Count;
		}
	}
}