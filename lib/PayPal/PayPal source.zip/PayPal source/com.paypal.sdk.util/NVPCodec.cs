using System;
using System.Collections.Specialized;
using System.Text;
using System.Web;

namespace com.paypal.sdk.util
{
	public sealed class NVPCodec : NameValueCollection
	{
		private const string AMPERSAND = "&";

		private const string EQUALS = "=";

		private readonly static char[] AMPERSAND_CHAR_ARRAY;

		private readonly static char[] EQUALS_CHAR_ARRAY;

		public string this[string name, int index]
		{
			get
			{
				return base[NVPCodec.GetArrayName(index, name)];
			}
			set
			{
				base[NVPCodec.GetArrayName(index, name)] = value;
			}
		}

		static NVPCodec()
		{
			NVPCodec.AMPERSAND_CHAR_ARRAY = "&".ToCharArray();
			NVPCodec.EQUALS_CHAR_ARRAY = "=".ToCharArray();
		}

		public NVPCodec()
		{
		}

		public void Add(string name, string value, int index)
		{
			this.Add(NVPCodec.GetArrayName(index, name), value);
		}

		public void Decode(string nvpstring)
		{
			base.Clear();
			string[] strArray = nvpstring.Split(NVPCodec.AMPERSAND_CHAR_ARRAY);
			for (int i = 0; i < (int)strArray.Length; i++)
			{
				string str = strArray[i];
				string[] strArray1 = str.Split(NVPCodec.EQUALS_CHAR_ARRAY);
				if ((int)strArray1.Length >= 2)
				{
					string str1 = NVPCodec.UrlDecode(strArray1[0]);
					string str2 = NVPCodec.UrlDecode(strArray1[1]);
					this.Add(str1, str2);
				}
			}
		}

		public string Encode()
		{
			StringBuilder stringBuilder = new StringBuilder();
			bool flag = true;
			string[] allKeys = this.AllKeys;
			for (int i = 0; i < (int)allKeys.Length; i++)
			{
				string str = allKeys[i];
				string str1 = NVPCodec.UrlEncode(str);
				string str2 = NVPCodec.UrlEncode(base[str]);
				if (!flag)
				{
					stringBuilder.Append("&");
				}
				stringBuilder.Append(str1).Append("=").Append(str2);
				flag = false;
			}
			return stringBuilder.ToString();
		}

		private static string GetArrayName(int index, string name)
		{
			if (index >= 0)
			{
				return string.Concat(name, index);
			}
			else
			{
				throw new ArgumentOutOfRangeException("index", string.Concat("index can not be negative : ", index));
			}
		}

		public void Remove(string arrayName, int index)
		{
			this.Remove(NVPCodec.GetArrayName(index, arrayName));
		}

		private static string UrlDecode(string s)
		{
			return HttpUtility.UrlDecode(s);
		}

		private static string UrlEncode(string s)
		{
			return HttpUtility.UrlEncode(s.Trim());
		}
	}
}