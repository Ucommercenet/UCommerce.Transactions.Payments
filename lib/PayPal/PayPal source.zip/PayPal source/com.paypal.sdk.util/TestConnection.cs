using com.paypal.sdk.profiles;
using com.paypal.sdk.services;
using System;

namespace com.paypal.sdk.util
{
	public class TestConnection
	{
		public TestConnection()
		{
		}

		public string testServerConnection(IAPIProfile pProfile)
		{
			NVPCallerServices nVPCallerService = new NVPCallerServices();
			nVPCallerService.Initialize();
			nVPCallerService.APIProfile = pProfile;
			NVPCodec nVPCodec = new NVPCodec();
			nVPCodec["METHOD"] = "TransactionSearch";
			nVPCodec["TRXTYPE"] = "Q";
			nVPCodec["STARTDATE"] = "1947-1-1T0:0:0";
			nVPCodec["ENDDATE"] = "1947-1-1T0:0:0";
			string str = nVPCodec.Encode();
			string str1 = nVPCallerService.Call(str);
			NVPCodec nVPCodec1 = new NVPCodec();
			nVPCodec1.Decode(str1);
			string item = nVPCodec1["ACK"];
			if (item == null || !(item == "Success") && !(item == "SuccessWithWarning"))
			{
				string[] strArray = new string[6];
				strArray[0] = "ErrorCode=";
				strArray[1] = nVPCodec1["L_ERRORCODE0"];
				strArray[2] = "&Desc=";
				strArray[3] = nVPCodec1["L_SHORTMESSAGE0"];
				strArray[4] = "&Desc2=";
				strArray[5] = nVPCodec1["L_LONGMESSAGE0"];
				string str2 = string.Concat(strArray);
				return str2;
			}
			else
			{
				return "Successfully Connected";
			}
		}
	}
}