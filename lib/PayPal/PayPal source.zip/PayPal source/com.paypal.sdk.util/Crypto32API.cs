using System;
using System.IO;
using System.Runtime.InteropServices;

namespace com.paypal.sdk.util
{
	public abstract class Crypto32API
	{
		public const string MY_STORE = "MY";

		public const string ROOT_STORE = "ROOT";

		public const uint CRYPT_USER_KEYSET = 4096;

		public const uint CERT_FIND_SUBJECT_STR = 524295;

		public const uint CERT_KEY_PROV_INFO_PROP_ID = 2;

		public const uint CERT_STORE_ADD_NEW = 2;

		public const uint CERT_SYSTEM_STORE_CURRENT_USER = 65536;

		public const uint CERT_STORE_READONLY_FLAG = 32768;

		public const uint CERT_STORE_OPEN_EXISTING_FLAG = 16384;

		public const uint CERT_SYSTEM_STORE_CURRENT_SERVICE = 3;

		public const uint CERT_SYSTEM_STORE_LOCAL_MACHINE = 131072;

		public const uint CERT_SYSTEM_STORE_MYSUSER_MACHINE = 65536;

		public const int CERT_STORE_PROV_LM_SYSTEM_STORE = 10;

		protected Crypto32API()
		{
		}

		[DllImport("crypt32.dll")]
		public static extern bool CertAddCertificateContextToStore(IntPtr hCertStore, IntPtr pCrlContext, uint dwAddDisposition, IntPtr ppStoreContext);

		[DllImport("crypt32.dll")]
		public static extern bool CertCloseStore(IntPtr hCertStore, uint dwFlags);

		[DllImport("crypt32.dll")]
		public static extern IntPtr CertEnumCertificatesInStore(IntPtr hCertStore, IntPtr pPrevCertContext);

		[DllImport("crypt32.dll", CharSet=CharSet.None)]
		public static extern IntPtr CertFindCertificateInStore(IntPtr hCertStore, uint dwCertEncodingType, uint dwFindFlags, uint dwFindType, string pvFindPara, IntPtr pPrevCertCntxt);

		[DllImport("crypt32.dll")]
		public static extern bool CertFreeCertificateContext(IntPtr hCertStore);

		[DllImport("crypt32.dll")]
		public static extern IntPtr CertOpenStore(IntPtr lpszStoreProvider, uint dwMsgAndCertEncodingType, IntPtr hCryptProv, uint dwFlags, string pvPara);

		[DllImport("crypt32.dll")]
		public static extern IntPtr CertOpenSystemStore(IntPtr hCryptProv, string storename);

		public static Crypto32API.CryptoDataBlob CopyByteToCryptoBlob(byte[] pfxData)
		{
			Crypto32API.CryptoDataBlob length = new Crypto32API.CryptoDataBlob();
			if (pfxData == null || (int)pfxData.Length == 0)
			{
				throw new Exception("Unable to read pfx file.");
			}
			else
			{
				length.cbData = (int)pfxData.Length;
				length.pbData = Marshal.AllocHGlobal((int)pfxData.Length);
				Marshal.Copy(pfxData, 0, length.pbData, (int)pfxData.Length);
				return length;
			}
		}

		public static bool IsValidPFXCertificate(Crypto32API.CryptoDataBlob pfxBlob)
		{
			return Crypto32API.PFXIsPFXBlob(ref pfxBlob);
		}

		[DllImport("crypt32.dll")]
		public static extern IntPtr PFXImportCertStore(ref Crypto32API.CryptoDataBlob pPfx, string szPassword, uint dwFlags);

		[DllImport("crypt32.dll")]
		public static extern bool PFXIsPFXBlob(ref Crypto32API.CryptoDataBlob pPfx);

		public static Crypto32API.CryptoDataBlob ReadPFXCertificateFile(string pfxFileName)
		{
			if (File.Exists(pfxFileName))
			{
				Stream fileStream = new FileStream(pfxFileName, FileMode.Open);
				int length = (int)fileStream.Length;
				byte[] numArray = new byte[length];
				fileStream.Seek((long)0, 0);
				fileStream.Read(numArray, 0, length);
				fileStream.Close();
				Crypto32API.CryptoDataBlob cryptoBlob = Crypto32API.CopyByteToCryptoBlob(numArray);
				return cryptoBlob;
			}
			else
			{
				throw new Exception(string.Format("File '{0}' not found.", pfxFileName));
			}
		}

		public struct CryptoDataBlob
		{
			public int cbData;

			public IntPtr pbData;
		}
	}
}