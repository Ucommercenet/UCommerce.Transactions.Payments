using System;
using System.IO;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Xml;

namespace com.paypal.sdk.util
{
	public class Utils
	{
		public const int DEFAULT_HTTPPOST_TIMEOUT = 10000;

		public Utils()
		{
		}

		public static XmlElement CreateXmlNode(Stream stream)
		{
			XmlDocument xmlDocument = new XmlDocument();
			Stream stream1 = stream;
			try
			{
				xmlDocument.Load(stream);
			}
			finally
			{
				if (stream1 != null)
				{
					stream1.Dispose();
				}
			}
			XmlElement documentElement = xmlDocument.DocumentElement;
			return documentElement;
		}

		public static XmlElement CreateXmlNode(StreamReader streamReader)
		{
			XmlDocument xmlDocument = new XmlDocument();
			StreamReader streamReader1 = streamReader;
			try
			{
				xmlDocument.Load(streamReader);
			}
			finally
			{
				if (streamReader1 != null)
				{
					streamReader1.Dispose();
				}
			}
			XmlElement documentElement = xmlDocument.DocumentElement;
			return documentElement;
		}

		public static string HttpPost(string url, string postData)
		{
			return Utils.HttpPost(url, postData, 10000, null);
		}

		public static string HttpPost(string url, string postData, int timeout, X509Certificate x509)
		{
			string end;
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
			httpWebRequest.Timeout = timeout;
			httpWebRequest.Method = "POST";
			httpWebRequest.ContentLength = postData.Length;
			if (x509 != null)
			{
				httpWebRequest.ClientCertificates.Add(x509);
			}
			StreamWriter streamWriter = new StreamWriter(httpWebRequest.GetRequestStream());
			try
			{
				streamWriter.Write(postData);
			}
			finally
			{
				if (streamWriter != null)
				{
					streamWriter.Dispose();
				}
			}
			WebResponse response = httpWebRequest.GetResponse();
			try
			{
				StreamReader streamReader = new StreamReader(response.GetResponseStream());
				try
				{
					end = streamReader.ReadToEnd();
				}
				finally
				{
					if (streamReader != null)
					{
						streamReader.Dispose();
					}
				}
			}
			finally
			{
				if (response != null)
				{
					response.Close();
				}
			}
			return end;
		}

		public static bool IsEmpty(string s)
		{
			if (s == null)
			{
				return true;
			}
			else
			{
				return s.Trim() == string.Empty;
			}
		}

		public static bool IsStage(string name)
		{
			bool flag = false;
			if (name.IndexOf("stage") >= 0)
			{
				flag = true;
			}
			return flag;
		}
	}
}