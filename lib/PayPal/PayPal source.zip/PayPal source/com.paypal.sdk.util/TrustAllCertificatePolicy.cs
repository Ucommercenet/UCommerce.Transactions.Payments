using System;
using System.Net;
using System.Security.Cryptography.X509Certificates;

namespace com.paypal.sdk.util
{
	public class TrustAllCertificatePolicy : ICertificatePolicy
	{
		public readonly static TrustAllCertificatePolicy Instance;

		static TrustAllCertificatePolicy()
		{
			TrustAllCertificatePolicy.Instance = new TrustAllCertificatePolicy();
		}

		private TrustAllCertificatePolicy()
		{
		}

		public bool CheckValidationResult(ServicePoint sp, X509Certificate cert, WebRequest request, int problem)
		{
			return true;
		}
	}
}