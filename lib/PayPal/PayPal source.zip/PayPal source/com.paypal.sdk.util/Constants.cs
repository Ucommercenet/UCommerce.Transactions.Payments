using System;

namespace com.paypal.sdk.util
{
	public class Constants
	{
		public readonly static string RESOURCE_ROOT;

		static Constants()
		{
			Constants.RESOURCE_ROOT = "com.paypal.sdk";
		}

		public Constants()
		{
		}
	}
}