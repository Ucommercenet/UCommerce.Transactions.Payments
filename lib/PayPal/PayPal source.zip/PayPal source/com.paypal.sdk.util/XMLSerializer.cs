using com.paypal.sdk.exceptions;
using System;
using System.IO;
using System.Reflection;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace com.paypal.sdk.util
{
	public abstract class XMLSerializer
	{
		protected XMLSerializer()
		{
		}

		public static object FromXML(string xml, Type type)
		{
			object obj;
			try
			{
				XmlSerializer xmlSerializer = new XmlSerializer(type);
				XmlReader xmlTextReader = new XmlTextReader(new StringReader(xml));
				obj = xmlSerializer.Deserialize(xmlTextReader);
			}
			catch (Exception exception1)
			{
				Exception exception = exception1;
				throw new TransactionException(MessageResources.GetMessage("DESERIALIZE_ERROR"), exception);
			}
			return obj;
		}

		private static void inflate(object obj)
		{
			Type type = obj.GetType();
			FieldInfo[] fields = type.GetFields(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly);
			for (int i = 0; i < (int)fields.Length; i++)
			{
				FieldInfo fieldInfo = fields[i];
				Type fieldType = fieldInfo.FieldType;
				if (!fieldType.IsEnum)
				{
					if (fieldType != typeof(string))
					{
						if (fieldType != typeof(bool))
						{
							if (!fieldType.IsArray)
							{
								try
								{
									object obj1 = Activator.CreateInstance(fieldType);
									XMLSerializer.inflate(obj1);
									fieldInfo.SetValue(obj, obj1);
								}
								catch (Exception exception)
								{
								}
							}
							else
							{
								try
								{
									Type elementType = fieldType.GetElementType();
									object obj2 = Activator.CreateInstance(elementType);
									XMLSerializer.inflate(obj2);
									Array array = Array.CreateInstance(elementType, 1);
									long[] numArray = new long[1];
									array.SetValue(obj2, numArray);
									fieldInfo.SetValue(obj, array);
								}
								catch (Exception exception1)
								{
								}
							}
						}
						else
						{
							fieldInfo.SetValue(obj, true);
						}
					}
					else
					{
						fieldInfo.SetValue(obj, "");
					}
				}
			}
		}

		public static string ToXML(object obj)
		{
			string str;
			try
			{
				StringWriter stringWriter = new StringWriter(new StringBuilder());
				XmlSerializer xmlSerializer = new XmlSerializer(obj.GetType());
				xmlSerializer.Serialize(stringWriter, obj);
				string str1 = stringWriter.ToString().Replace("xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"", "");
				str1 = str1.Replace("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"", "");
				str1 = str1.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", "").Trim();
				str = str1;
			}
			catch (Exception exception1)
			{
				Exception exception = exception1;
				throw new TransactionException(MessageResources.GetMessage("SERIALIZE_ERROR"), exception);
			}
			return str;
		}

		public static string ToXMLTemplate(object obj)
		{
			XMLSerializer.inflate(obj);
			return XMLSerializer.ToXML(obj);
		}
	}
}