using System;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Threading;

namespace com.paypal.sdk.util
{
	public abstract class MessageResources
	{
		protected static ResourceManager ResourceBundle;

		static MessageResources()
		{
			MessageResources.ResourceBundle = new ResourceManager(string.Concat(Constants.RESOURCE_ROOT, ".util.Resource"), Assembly.GetExecutingAssembly());
		}

		protected MessageResources()
		{
		}

		public static string GetMessage(string message)
		{
			return MessageResources.ResourceBundle.GetString(message);
		}

		public static void SetLocale(string language, string country)
		{
			string str = string.Concat(language, "-", country);
			Thread.CurrentThread.CurrentUICulture = new CultureInfo(str);
		}
	}
}