﻿using System.Reflection;

[assembly: AssemblyCompany("PayPal")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright (C) 2005 DTS PayPal. All Rights Reserved.")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyDescription("")]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyTitle("base")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("5.6.64.0")]
