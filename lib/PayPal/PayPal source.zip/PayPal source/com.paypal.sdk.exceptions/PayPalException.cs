using System;

namespace com.paypal.sdk.exceptions
{
	public abstract class PayPalException : Exception
	{
		public PayPalException()
		{
		}

		public PayPalException(string message) : base(message)
		{
		}

		public PayPalException(string message, Exception cause) : base(message, cause)
		{
		}
	}
}