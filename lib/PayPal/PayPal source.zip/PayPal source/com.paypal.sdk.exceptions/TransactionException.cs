using log4net;
using System;

namespace com.paypal.sdk.exceptions
{
	public class TransactionException : PayPalException
	{
		private static ILog log;

		static TransactionException()
		{
			TransactionException.log = LogManager.GetLogger("com.paypal.sdk.exceptions.TransactionException");
		}

		public TransactionException()
		{
		}

		public TransactionException(string message) : base(message)
		{
			if (TransactionException.log.IsErrorEnabled)
			{
				TransactionException.log.Error(message, this);
			}
		}

		public TransactionException(string message, Exception cause) : base(message, cause)
		{
			if (TransactionException.log.IsErrorEnabled)
			{
				TransactionException.log.Error(message, this);
			}
		}
	}
}