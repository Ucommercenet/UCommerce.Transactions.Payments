using log4net;
using System;

namespace com.paypal.sdk.exceptions
{
	public class WarningException : PayPalException
	{
		private static ILog log;

		static WarningException()
		{
			WarningException.log = LogManager.GetLogger("com.paypal.sdk.exceptions.WarningException");
		}

		public WarningException()
		{
		}

		public WarningException(string message) : base(message)
		{
			if (WarningException.log.IsWarnEnabled)
			{
				WarningException.log.Warn(message, this);
			}
		}

		public WarningException(string message, Exception cause) : base(message, cause)
		{
			if (WarningException.log.IsWarnEnabled)
			{
				WarningException.log.Warn(message, cause);
			}
		}
	}
}