using log4net;
using System;

namespace com.paypal.sdk.exceptions
{
	public class FatalException : PayPalException
	{
		private static ILog log;

		static FatalException()
		{
			FatalException.log = LogManager.GetLogger("com.paypal.sdk.exceptions.FatalException");
		}

		public FatalException()
		{
		}

		public FatalException(string message) : base(message)
		{
			if (FatalException.log.IsFatalEnabled)
			{
				FatalException.log.Fatal(message, this);
			}
		}

		public FatalException(string message, Exception cause) : base(message, cause)
		{
			if (FatalException.log.IsFatalEnabled)
			{
				FatalException.log.Fatal(message, cause);
			}
		}
	}
}