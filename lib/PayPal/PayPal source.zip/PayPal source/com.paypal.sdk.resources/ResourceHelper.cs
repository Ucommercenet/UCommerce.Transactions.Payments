using com.paypal.sdk.util;
using System;
using System.IO;
using System.Reflection;

namespace com.paypal.sdk.resources
{
	public class ResourceHelper
	{
		public ResourceHelper()
		{
		}

		public static Stream GetResourceStream(string name)
		{
			return Assembly.GetExecutingAssembly().GetManifestResourceStream(string.Concat(Constants.RESOURCE_ROOT, name));
		}
	}
}