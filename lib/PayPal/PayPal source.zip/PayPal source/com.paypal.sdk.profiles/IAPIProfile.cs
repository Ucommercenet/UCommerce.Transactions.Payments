using System;

namespace com.paypal.sdk.profiles
{
	public interface IAPIProfile
	{
		string APIPassword
		{
			get;
			set;
		}

		string APISignature
		{
			get;
			set;
		}

		string APIUsername
		{
			get;
			set;
		}

		string CertificateFile
		{
			get;
			set;
		}

		int DelayTime
		{
			get;
			set;
		}

		string Environment
		{
			get;
			set;
		}

		string getFirstPartyEmail
		{
			get;
			set;
		}

		int MaximumRetries
		{
			get;
			set;
		}

		string PrivateKeyPassword
		{
			get;
			set;
		}

		string Subject
		{
			get;
			set;
		}

		int Timeout
		{
			get;
			set;
		}

	}
}