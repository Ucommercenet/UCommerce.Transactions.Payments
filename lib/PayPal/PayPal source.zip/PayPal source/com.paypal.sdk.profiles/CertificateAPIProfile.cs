using com.paypal.sdk.exceptions;
using com.paypal.sdk.util;
using System;

namespace com.paypal.sdk.profiles
{
	[Serializable]
	public class CertificateAPIProfile : BaseAPIProfile
	{
		private string certificateFile;

		private string privateKeyPassword;

		public override string APISignature
		{
			get
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
			set
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
		}

		public override string CertificateFile
		{
			get
			{
				return this.certificateFile;
			}
			set
			{
				this.certificateFile = value;
			}
		}

		public override string getFirstPartyEmail
		{
			get
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
			set
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
		}

		public override string PrivateKeyPassword
		{
			get
			{
				return this.privateKeyPassword;
			}
			set
			{
				this.privateKeyPassword = value;
			}
		}

		public CertificateAPIProfile()
		{
			this.certificateFile = string.Empty;
			this.privateKeyPassword = "";
		}
	}
}