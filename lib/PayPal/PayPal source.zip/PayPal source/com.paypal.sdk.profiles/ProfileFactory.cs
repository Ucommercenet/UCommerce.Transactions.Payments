namespace com.paypal.sdk.profiles
{
	public class ProfileFactory
	{
		public ProfileFactory()
		{
		}

		public static IAPIProfile createSignatureAPIProfile()
		{
			return new SignatureAPIProfile();
		}

		public static IAPIProfile createSSLAPIProfile()
		{
			return new CertificateAPIProfile();
		}

		public static IAPIProfile createUniPayAPIProfile()
		{
			return new UniPayAPIProfile();
		}
	}
}