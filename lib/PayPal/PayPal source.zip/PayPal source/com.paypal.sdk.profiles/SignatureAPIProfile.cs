using com.paypal.sdk.exceptions;
using com.paypal.sdk.util;
using System;

namespace com.paypal.sdk.profiles
{
	[Serializable]
	public class SignatureAPIProfile : BaseAPIProfile, IAPIProfile
	{
		[NonSerialized]
		private string apiSignature;

		public override string APISignature
		{
			get
			{
				return this.apiSignature;
			}
			set
			{
				this.apiSignature = value;
			}
		}

		public override string CertificateFile
		{
			get
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
			set
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
		}

		public override string getFirstPartyEmail
		{
			get
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
			set
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
		}

		public override string PrivateKeyPassword
		{
			get
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
			set
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
		}

		public SignatureAPIProfile()
		{
		}
	}
}