using com.paypal.sdk.exceptions;
using com.paypal.sdk.util;
using System;

namespace com.paypal.sdk.profiles
{
	[Serializable]
	public class UniPayAPIProfile : BaseAPIProfile, IAPIProfile
	{
		[NonSerialized]
		private string emailSubject;

		public override string APISignature
		{
			get
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
			set
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
		}

		public override string CertificateFile
		{
			get
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
			set
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
		}

		public override string getFirstPartyEmail
		{
			get
			{
				return this.emailSubject;
			}
			set
			{
				this.emailSubject = value;
			}
		}

		public override string PrivateKeyPassword
		{
			get
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
			set
			{
				throw new FatalException(MessageResources.GetMessage("INVALID_PROFILE_OPERATION"));
			}
		}

		public UniPayAPIProfile()
		{
		}
	}
}