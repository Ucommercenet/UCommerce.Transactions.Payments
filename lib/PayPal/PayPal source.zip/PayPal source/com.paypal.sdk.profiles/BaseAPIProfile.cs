using com.paypal.sdk.core;
using log4net;
using System;

namespace com.paypal.sdk.profiles
{
	[Serializable]
	public abstract class BaseAPIProfile : IAPIProfile
	{
		private static ILog log;

		private string apiUsername;

		[NonSerialized]
		private string apiPassword;

		[NonSerialized]
		private string subject;

		private string environment;

		private int timeout;

		private int maximumRetries;

		private int delayTime;

		public string APIPassword
		{
			get
			{
				return this.apiPassword;
			}
			set
			{
				this.apiPassword = value;
			}
		}

		public abstract string APISignature
		{
			get;
			set;
		}

		public string APIUsername
		{
			get
			{
				return this.apiUsername;
			}
			set
			{
				this.apiUsername = value;
			}
		}

		public abstract string CertificateFile
		{
			get;
			set;
		}

		public int DelayTime
		{
			get
			{
				return this.delayTime;
			}
			set
			{
				if (value >= 0)
				{
					this.delayTime = value;
				}
			}
		}

		public string Environment
		{
			get
			{
				return this.environment;
			}
			set
			{
				this.environment = value;
			}
		}

		public abstract string getFirstPartyEmail
		{
			get;
			set;
		}

		public int MaximumRetries
		{
			get
			{
				return this.maximumRetries;
			}
			set
			{
				if (value >= 0)
				{
					this.maximumRetries = value;
				}
			}
		}

		public abstract string PrivateKeyPassword
		{
			get;
			set;
		}

		public string Subject
		{
			get
			{
				return this.subject;
			}
			set
			{
				this.subject = value;
			}
		}

		public int Timeout
		{
			get
			{
				return this.timeout;
			}
			set
			{
				if (value >= 0)
				{
					this.timeout = value;
				}
			}
		}

		static BaseAPIProfile()
		{
			BaseAPIProfile.log = LogManager.GetLogger("com.paypal.sdk.profiles.BaseAPIProfile");
		}

		public BaseAPIProfile()
		{
			this.apiUsername = string.Empty;
			this.environment = "sandbox";
			try
			{
				this.timeout = 360000;
				this.maximumRetries = Config.Instance.MaximumRetries;
				this.delayTime = 2000;
			}
			catch (Exception exception1)
			{
				Exception exception = exception1;
				BaseAPIProfile.log.Warn(exception.Message, exception);
			}
		}
	}
}