using com.paypal.sdk.core;
using com.paypal.sdk.core.nvp;
using com.paypal.sdk.exceptions;
using com.paypal.sdk.profiles;
using com.paypal.sdk.util;
using System;

namespace com.paypal.sdk.services
{
	public class NVPCallerServices
	{
		private NVPAPICaller caller;

		private bool initialized;

		public IAPIProfile APIProfile
		{
			get
			{
				return this.caller.Profile;
			}
			set
			{
				if (!this.initialized)
				{
					this.Initialize();
				}
				this.caller.Profile = value;
			}
		}

		public NVPCallerServices()
		{
			this.initialized = false;
		}

		public string Call(string requestnvp)
		{
			if (!this.initialized)
			{
				this.Initialize();
			}
			if (requestnvp != null)
			{
				string str = this.caller.Call(requestnvp);
				return str;
			}
			else
			{
				throw new TransactionException(string.Concat(MessageResources.GetMessage("INVALID_METHOD"), " : ", requestnvp));
			}
		}

		public void Initialize()
		{
			this.caller = (NVPAPICaller)APICallerFactory.createNVPAPICaller();
			this.initialized = true;
		}
	}
}